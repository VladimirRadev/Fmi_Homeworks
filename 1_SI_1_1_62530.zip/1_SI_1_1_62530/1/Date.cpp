/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 1
* @compiler VC
*/
#include"Date.hpp"

// private Method created to store count of days of each month
void Date::setDaysInMonth()
{
	//default
	daysInMonth[0] = -1;
	//indexes of this array will represent months in a year , January is 1 , and so..
	daysInMonth[1] = 31;
	daysInMonth[2] = 28; // if year is leap then february should have 29 days
	daysInMonth[3] = 31;
	daysInMonth[4] = 30;
	daysInMonth[5] = 31;
	daysInMonth[6] = 30;
	daysInMonth[7] = 31;
	daysInMonth[8] = 31;
	daysInMonth[9] = 30;
	daysInMonth[10] = 31;
	daysInMonth[11] = 30;
	daysInMonth[12] = 31;
}

//1 (Problem description's subpoint)
Date::Date() :day(1), month(1), year(2001)
{
	setDaysInMonth();
}

//2 (Problem description's subpoint)
Date::Date(int day, int month, int year)
{
	this->day = day;
	this->month = month;
	this->year = year;
	setDaysInMonth();
}

int Date::getDay()const
{
	return this->day;
}
int Date::getMonth()const
{
	return this->month;
}
int Date::getYear()const
{
	return this->year;
}

//3 (Problem description's subpoint)
void Date::addDays(int daysToAdd)
{
	bool currentYearIsLeap = isLeapYear();
	if (currentYearIsLeap)
	{
		daysInMonth[2] = 29;
	}
	while (daysToAdd > 0)
	{
		if (day + daysToAdd <= daysInMonth[month])
		{
			day += daysToAdd;
			daysToAdd = 0;

		}
		else
		{
			if (day + daysToAdd == daysInMonth[month] + 1)
			{
				day = 1;
				daysToAdd = 0;
				if (month + 1 > 12)
				{
					year += 1;
					if (isLeapYear())
					{
						daysInMonth[2] = 29;

					}
					else
					{
						daysInMonth[2] = 28;
					}
					month = 1;
				}
				else
				{
					month += 1;
				}
			}
			else
			{
				daysToAdd -= daysInMonth[month] - day + 1;
				day = 1;
				if (month + 1 > 12)
				{
					year += 1;
					if (isLeapYear())
					{
						daysInMonth[2] = 29;

					}
					else
					{
						daysInMonth[2] = 28;
					}
					month = 1;
				}
				else
				{
					month += 1;
				}
			}

		}

	}
	return;

}

//4 (Problem description's subpoint)
void Date::removeDays(int daysToRemove)
{
	bool currentYearIsLeap = isLeapYear();
	if (currentYearIsLeap)
	{
		daysInMonth[2] = 29;
	}
	while (daysToRemove > 0)
	{
		if (daysToRemove >= day)
		{
			daysToRemove -= day;
			if (month - 1 <= 0)
			{
				month = 12;
				year -= 1;
				if (isLeapYear())
				{
					daysInMonth[2] = 29;
				}
				else
				{
					daysInMonth[2] = 28;;
				}
			}
			else
			{
				month -= 1;
				day = daysInMonth[month];

			}
		}
		else
		{
			day -= daysToRemove;
			daysToRemove = 0;
		}

	}
	return;

}

//5 (Problem description's subpoint)
bool Date::isLeapYear()const
{
	if (year % 4 == 0)
	{
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		return false;
	}
}

//Help Method used in DaysToXmas() 
bool Date::isLeapYear(int year)const
{
	if (year % 4 == 0)
	{
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		return false;
	}

}

//6 (Problem description's subpoint)
int Date::DaysToXmas()const
{
	const int XMAS_DAY = 25;
	const int XMAS_MONTH = 12;
	int daysToXmas = 0;
	int currentDay = day, currentMonth = month, currentYear = year;
	int currentCalendar[13] = { -1,31,28,31,30,31,30,31,31,30,31,30,31 };
	if (isLeapYear(currentYear))
	{
		currentCalendar[2] = 29;
	}
	while (!(currentDay == XMAS_DAY && currentMonth == XMAS_MONTH))
	{
		if (currentMonth == XMAS_MONTH)
		{
			if (currentDay <= XMAS_DAY)
			{
				daysToXmas += (XMAS_DAY - currentDay);
				currentDay = XMAS_DAY;
				currentMonth = XMAS_MONTH;
			}
			//day is in december but after xmas
			else
			{
				daysToXmas += (currentCalendar[XMAS_MONTH] - currentDay) + 1;
				currentDay = 1;
				currentMonth = 1;
				currentYear += 1;
				if (isLeapYear(currentYear))
				{
					currentCalendar[2] = 29;
				}
				else
				{
					currentCalendar[2] = 28;
				}
			}
		}
		else
		{
			daysToXmas += (currentCalendar[currentMonth] - currentDay) + 1;
			currentDay = 1;
			currentMonth += 1;

		}
	}
	return daysToXmas;
}

//7 (Problem description's subpoint)
int Date::DaysToEndOfTheYear()const
{
	const int NEW_YEAR_DAY = 1;
	const int NEW_YEAR_MONTH = 1;
	const int DECEMBER_MONTH = 12;
	int daysToNewYear = 0;
	int currentDay = day, currentMonth = month, currentYear = year;
	int currentCalendar[13] = { -1,31,28,31,30,31,30,31,31,30,31,30,31 };
	if (isLeapYear(currentYear))
	{
		currentCalendar[2] = 29;
	}
	while (!(currentDay == NEW_YEAR_DAY && currentMonth == NEW_YEAR_MONTH && currentYear == year + 1))
	{
		if (currentMonth == DECEMBER_MONTH)
		{
			daysToNewYear += (currentCalendar[currentMonth] - currentDay) + 1;
			currentDay = 1;
			currentMonth = 1;
			currentYear += 1;
		}
		else
		{
			daysToNewYear += (currentCalendar[currentMonth] - currentDay) + 1;
			currentDay = 1;
			++currentMonth;

		}
	}
	return daysToNewYear;
}

//8 (Problem description's subpoint)
int Date::DaysToEvent(const Date& eventDate)const
{
	//catch eventDate before this date exception (when we are trying to count days to past event)
	if (!this->isLaterThen(eventDate))
	{
		return -1;
	}
	const int EVENT_DATE_DAY = eventDate.getDay();
	const int EVENT_DATE_MONTH = eventDate.getMonth();
	const int EVENT_DATE_YEAR = eventDate.getYear();
	int daysRemainToEvent = 0;
	int currentDay = day, currentMonth = month, currentYear = year;
	int currentCalendar[13] = { -1,31,28,31,30,31,30,31,31,30,31,30,31 };
	if (isLeapYear(currentYear))
	{
		currentCalendar[2] = 29;
	}
	while (!(currentDay == EVENT_DATE_DAY && currentMonth == EVENT_DATE_MONTH && currentYear == EVENT_DATE_YEAR))
	{
		if (currentYear == EVENT_DATE_YEAR)
		{
			if (currentMonth == EVENT_DATE_MONTH)
			{
				if (currentDay == EVENT_DATE_DAY)
				{
					break;
				}
				else
				{
					daysRemainToEvent += (EVENT_DATE_DAY - currentDay);
					currentDay = EVENT_DATE_DAY;
				}
			}
			else
			{
				daysRemainToEvent += (currentCalendar[currentMonth] - currentDay) + 1;
				currentDay = 1;
				++currentMonth;
			}
		}
		else
		{
			daysRemainToEvent += (currentCalendar[currentMonth] - currentDay) + 1;
			if (currentMonth + 1 > 12)
			{
				currentMonth = 1;
				currentDay = 1;
				++currentYear;
				if (isLeapYear(currentYear))
				{
					currentCalendar[2] = 29;
				}
				else
				{
					currentCalendar[2] = 28;
				}

			}
			else
			{
				currentDay = 1;
				++currentMonth;
			}
		}
	}
	return daysRemainToEvent;
}

//9 (Problem description's subpoint)
bool Date::isLaterThen(const Date& dateCompare)const
{
	if (year < dateCompare.getYear())
	{
		return true;
	}
	else if (year == dateCompare.getYear())
	{
		if (month < dateCompare.getMonth())
		{
			return true;
		}
		else if (month == dateCompare.getMonth())
		{
			if (day < dateCompare.getDay())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}