/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 1
* @compiler VC
*/
#ifndef Date1
#define Date1 1
#include <iostream>
using namespace std;
class Date
{
private:
	int day;
	int month;
	int year;
	int daysInMonth[13];
	void setDaysInMonth();
public:
	Date();
	Date(int day, int month, int year);
	int getDay()const;
	int getMonth()const;
	int getYear()const;
	void addDays(int daysToAdd);
	void removeDays(int daysToRemove);
	bool isLeapYear()const;
	bool isLeapYear(int year)const;
	int DaysToXmas()const;
	int DaysToEndOfTheYear()const;
	int DaysToEvent(const Date& eventDate)const;
	bool isLaterThen(const Date& dateCompare)const;
	void print()const
	{
		cout << day << ":" << month << ":" << year << endl;
	}

};
#endif // !Date1
