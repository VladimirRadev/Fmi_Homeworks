/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#include "Deck.hpp"
#include <iostream>
using namespace std;
int Deck::sizeOfTakenIndexes(const int* cardDesk) const
{
	int takenSize = 0;
	for (int i = 0; i < 20; i++)
	{
		if (cardDesk[i] == 1)
		{
			++takenSize;
		}
	}
	return takenSize;
}
Deck::Deck()
{
	for (int i = 0; i < 20; i++)
	{
		takenIndexesOfMagicCards[i] = 0;
	}
	for (int i = 0; i < 20; i++)
	{
		takenIndexesOfMonsterCards[i] = 0;
	}
	for (int i = 0; i < 20; i++)
	{
		MagicCard d = MagicCard();
		magicCards[i] = d;
	}
	for (int i = 0; i < 20; i++)
	{
		MonsterCard d = MonsterCard();
		monsterCards[i] = d;
	}
}

//8 Method which add/(replace and push other elements right) magicCard at given index
void Deck::changeMonsterCard(const int index, const MonsterCard& monsterCard)
{
	if (index < 0 || index >= 20)
	{
		cout << "Index out of monstercards desk bounds" << endl;
		return;
	}
	if (takenIndexesOfMonsterCards[index] == 1 && index == 19)
	{
		cout << "Not possible change of monster card at this index!" << endl;
		return;

	}
	else if (takenIndexesOfMonsterCards[index] == 1)
	{
		bool isPosiible = true;
		int firstFreeIndexToPushRight = index + 1;
		while (takenIndexesOfMonsterCards[firstFreeIndexToPushRight] == 1)
		{
			if (firstFreeIndexToPushRight + 1 <= 19)
			{
				++firstFreeIndexToPushRight;
			}
			else
			{
				isPosiible = false;
			}
		}
		if (!isPosiible)
		{
			cout << "Not possible change of monster card at this index!" << endl;
			return;
		}
		for (int i = firstFreeIndexToPushRight; i >= index + 1; i--)
		{
			monsterCards[i] = MonsterCard(monsterCards[i - 1]);
		}
		//we catch the dynamic alocated name array then with the setname method we set
		//monsterCards[index] name with a copy of  ptr
		//then we delete ptr so we insurance the program does not leak memory
		char* ptr = monsterCard.getName();
		monsterCards[index].setName(ptr);
		monsterCards[index].setAttackPoints(monsterCard.getAttackPoints());
		monsterCards[index].setDefencePoints(monsterCard.getDefencePoints());
		takenIndexesOfMonsterCards[firstFreeIndexToPushRight] = 1;
		delete[]ptr;
		return;
	}
	else
	{
		char* ptr = monsterCard.getName();
		monsterCards[index].setName(ptr);
		monsterCards[index].setAttackPoints(monsterCard.getAttackPoints());
		monsterCards[index].setDefencePoints(monsterCard.getDefencePoints());

		//we say that on index x stay something and set the value on position x to 1
		//otherwise on index x will stay 0 indicate us that has not element there
		takenIndexesOfMonsterCards[index] = 1;
		delete[]ptr;
		return;
	}
}
//4 (Problem Descripton)
int Deck::getMonsterCardCount()const
{
	return sizeOfTakenIndexes(takenIndexesOfMonsterCards);
}
//3 (Problem Descripton)
int Deck::getMagicCardCount()const
{
	return sizeOfTakenIndexes(takenIndexesOfMagicCards);
}
//5 (Problem Descripton)
void Deck::addMagicCard(const MagicCard& magicCard)
{
	bool isFull = true;
	for (int i = 0; i < 20; i++)
	{
		if (takenIndexesOfMagicCards[i] == 0)
		{
			char* dynName = magicCard.getName();
			char* dynEffect = magicCard.getEffect();
			magicCards[i].setName(dynName);
			magicCards[i].setEffect(dynEffect);
			magicCards[i].setType(magicCard.getType());

			// we say that on index x stay something and set the value on position x to 1
			//otherwise on index x will stay 0 indicate us that has not element there
			takenIndexesOfMagicCards[i] = 1;
			isFull = false;
			delete[]dynName;
			delete[]dynEffect;
			break;
		}

	}
	if (isFull)
	{
		cout << "No more available space in magic cards desk" << endl;
		return;
	}
}
//6 (Problem Descripton)
void Deck::addMonsterCard(const MonsterCard& monsterCard)
{
	bool isFull = true;
	for (int i = 0; i < 20; i++)
	{
		if (takenIndexesOfMonsterCards[i] == 0)
		{
			char* ptr = monsterCard.getName();
			monsterCards[i].setName(ptr);
			monsterCards[i].setAttackPoints(monsterCard.getAttackPoints());
			monsterCards[i].setDefencePoints(monsterCard.getDefencePoints());

			//we say that on index x stay something and set the value on position x to 1
			//otherwise on index x will stay 0 indicate us that has not element there
			takenIndexesOfMonsterCards[i] = 1;
			isFull = false;
			delete[]ptr;
			break;
		}

	}
	if (isFull)
	{
		cout << "No more available space in monster cards desk" << endl;
		return;
	}
}
//7 Method which change/add magicCard at given index
void Deck::changeMagicCard(const int index, const MagicCard& magicCard)

{
	if (index < 0 || index >= 20)
	{
		cout << "Index outside the magic cards desk bounds " << endl;
		return;
	}
	char* dynName = magicCard.getName();
	char* dynEffect = magicCard.getEffect();
	takenIndexesOfMagicCards[index] = 1;
	magicCards[index].setName(dynName);
	magicCards[index].setEffect(dynEffect);
	magicCards[index].setType(magicCard.getType());
	delete[]dynName;
	delete[]dynEffect;

}

void Deck::print()const
{
	cout << "monster cards in deck: are" << endl;
	for (int i = 0; i < 20; i++)
	{
		if (takenIndexesOfMonsterCards[i] == 1)
		{
			char* ptr = monsterCards[i].getName();
			cout << "At index:" << i << " "<<ptr<< " : " << monsterCards[i].getAttackPoints() <<" " <<monsterCards[i].getDefencePoints()<<" ";
			cout << endl;
			delete[]ptr;
		}
	}
	cout << "magic cards in deck: are" << endl;
	for (int i = 0; i < 20; i++)
	{
		if (takenIndexesOfMagicCards[i] == 1)
		{
			char* ptr1 = magicCards[i].getName();
			char* ptr2 = magicCards[i].getEffect();
			cout << "At index:" << i << " " << ptr1 << "with effect " << ptr2 << ":" << magicCards[i].getTypeAsString();
			cout << endl;
			delete[]ptr1;
			delete[]ptr2;
		}
	}
}