/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#ifndef Deck1 
#define Deck1 1

#include<cstring>
#include"MagicCard.hpp"
#include"MonsterCard.hpp"

class Deck
{
private:
	//array contains taken indexes, when actual card with information stays at index x,
	//takenIndexesOfMonsterCards[x]=1, otherwise value will be 0
	int takenIndexesOfMonsterCards[20];
	int takenIndexesOfMagicCards[20];
	MonsterCard monsterCards[20];
	MagicCard magicCards[20];
	int sizeOfTakenIndexes(const int* cardDesk) const;
public:
	Deck();
	void changeMonsterCard(const int index, const MonsterCard& monsterCard);
	int getMonsterCardCount()const;
	void changeMagicCard(const int index, const MagicCard& magicCard);
	int getMagicCardCount()const;
	void addMagicCard(const MagicCard& magicCard);
	void addMonsterCard(const MonsterCard& monsterCard);
	void print()const;
};
#endif // !Desk1 


