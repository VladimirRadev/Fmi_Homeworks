/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#include "Duelist.hpp"
#include <iostream>
using namespace std;
int Duelist::sizeOfStr(const char* name)const
{
	int size = 0;
	while (*(name + size) != '\0')
	{
		++size;
	}
	return size;
}
Duelist::Duelist(const char* name)
{
	setName(name);

	//calling default constuctor to create empty deck of duelist
	this->deck = Deck();
}
Duelist::~Duelist()
{
	delete []name;
}
void Duelist::setName(const char* inputName)
{
	if (inputName == NULL)
	{
		cout << "Duelist must have non empty name" << endl;
		return;

	}
	delete[]name;
	int sizeOfname = sizeOfStr(inputName);
	name = new char[sizeOfname + 1];
	for (int i = 0; i < sizeOfname; i++)
	{
		name[i] = inputName[i];
	}
	name[sizeOfname] = '\0';
	return;
}
char* Duelist::getName()const
{
	return name;
}

//8 Method which add/(replace and push other elements right) magicCard at given index
void Duelist::changeMonsterCardInDeck(const int index, const MonsterCard& monsterCard)
{
	this->deck.changeMonsterCard(index, monsterCard);
}

//4 (Problem Descripton)
int Duelist::getMonsterCardInDeck()const
{
	return this->deck.getMonsterCardCount();
}

//7 Method which change/add magicCard at given index
void Duelist::changeMagicCardInDeck(const int index, const MagicCard& magicCard)
{
	this->deck.changeMagicCard(index, magicCard);
}

//3 (Problem Descripton)
int Duelist::getMagicCardInDeck()const
{
	return this->deck.getMagicCardCount();
}

//5 (Problem Descripton)
void Duelist::addMagicCardInDeck(const MagicCard& magicCard)
{
	this->deck.addMagicCard(magicCard);

}

//6 (Problem Descripton)
void Duelist::addMonsterCardInDeck(const MonsterCard& monsterCard)
{
	this->deck.addMonsterCard(monsterCard);
}