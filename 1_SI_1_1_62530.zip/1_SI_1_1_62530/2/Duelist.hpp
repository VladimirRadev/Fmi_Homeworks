/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#ifndef Duelist1
#define Duelist1 1

#include "Deck.hpp"
#include<cstring>

class Duelist 
{
private:
	char* name;
	Deck deck;
	int sizeOfStr(const char* name)const;
public:
	Duelist(const char* name);
	~Duelist();
	void setName(const char* name);
	char* getName()const;
	void changeMonsterCardInDeck(const int index, const MonsterCard& monsterCard);
	int getMonsterCardInDeck()const;
	void changeMagicCardInDeck(const int index, const MagicCard& magicCard);
	int getMagicCardInDeck()const;
	void addMagicCardInDeck(const MagicCard& magicCard);
	void addMonsterCardInDeck(const MonsterCard& monsterCard);
};
#endif // !Duelist1
