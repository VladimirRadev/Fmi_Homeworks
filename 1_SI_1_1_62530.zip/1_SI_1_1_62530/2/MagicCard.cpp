/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#include"MagicCard.hpp"
#include <iostream>
using namespace std;

void MagicCard::myStrCopy(char* destination, const char* source, const int sizeOfSource)
{
	for (int i = 0; i < sizeOfSource; i++)
	{
		destination[i] = source[i];
	}
	destination[sizeOfSource] = '\0';
	return;
}
int MagicCard::sizeOfStr(const char* str)
{
	int size = 0;
	while (*(str + size) != '\0')
	{
		++size;
	}
	return size;
}
MagicCard::MagicCard()
{
	name[0] = '\0';
	effect[0] = '\0';
	//hardcode default type to spell;
	setType(spell);
}
MagicCard::MagicCard(const char name[25], const char effect[100], const TypeMagicCard& type)
{
	setName(name);
	setEffect(effect);
	setType(type);
}
void MagicCard::setName(const char inputName[25])
{
	int sizeOfInputName = sizeOfStr(inputName);
	if (sizeOfInputName == 0)
	{
		name[0] = '\0';
		return;
	}
	else if (sizeOfInputName < 1 || sizeOfInputName >= 25)
	{
		return;
	}
	else
	{

		myStrCopy(name, inputName, sizeOfInputName);
	}
}
char* MagicCard::getName()const
{
	int sizeOfname = 0;
	for (int i = 0; name[i] != '\0'; i++)
	{
		++sizeOfname;

	}
	char* nameDynamic = new char[sizeOfname + 1];
	for (int i = 0; i < sizeOfname; i++)
	{
		nameDynamic[i] = name[i];
	}
	nameDynamic[sizeOfname] = '\0';
	return nameDynamic;
}
void MagicCard::setEffect(const char inputEffect[100])
{
	int sizeOfInputEffect = sizeOfStr(inputEffect);
	if (sizeOfInputEffect == 0)
	{
		effect[0] = '\0';
		return;
	}
	else if (sizeOfInputEffect < 1 || sizeOfInputEffect >= 100)
	{
		return;
	}
	else
	{
		myStrCopy(effect, inputEffect, sizeOfInputEffect);
	}
	return;
}
char* MagicCard::getEffect()const
{
	int sizeOfEffect = 0;
	for (int i = 0; effect[i] != '\0'; i++)
	{
		++sizeOfEffect;

	}
	char* effectDynamic = new char[sizeOfEffect + 1];
	for (int i = 0; i < sizeOfEffect; i++)
	{
		effectDynamic[i] = effect[i];
	}
	effectDynamic[sizeOfEffect] = '\0';
	return effectDynamic;
}
void MagicCard::setType(const TypeMagicCard& type)
{
	this->type = type;
}
TypeMagicCard MagicCard::getType()const
{
	return type;
}
const char* MagicCard::getTypeAsString()const
{
	if (this->type == 0)
	{
		return "trap";
	}
	else if (this->type == 1)
	{
		return "buff";
	}
	else if (this->type == 2)
	{
		return "spell";
	}
	else
	{
		return "Default type";
	}
}
