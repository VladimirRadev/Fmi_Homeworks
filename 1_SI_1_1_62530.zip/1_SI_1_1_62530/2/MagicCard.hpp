/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#ifndef MagicCard1
#define MagicCard1 1
#include <cstring>
enum TypeMagicCard
{
	trap,
	buff,
	spell
};
class MagicCard
{
private:
	char name[25];
	char effect[100];
	TypeMagicCard type;
	int sizeOfStr(const char* str);
	void myStrCopy(char* destination, const char* source, const int sizeOfSource);
public:
	MagicCard();
	MagicCard(const char name[25], const char effect[100], const TypeMagicCard& type);
	void setName(const char name[25]);
	char* getName()const;
	void setEffect(const char effect[100]);
	char* getEffect()const;
	void setType(const TypeMagicCard& type);
	TypeMagicCard getType()const;
	//this method returns dynamic created char pointer so be careful
	const char* getTypeAsString()const;
};

#endif // !MagicCard1
