/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/
#include "MonsterCard.hpp"
#include <iostream>
using namespace std;
int MonsterCard::sizeOfStr(const char* str)
{
	int size = 0;
	while (*(str+size)!='\0')
	{
		++size;
	}
	return size;
}
void MonsterCard::myStrCopy(char* destination, const char* source, const int sizeOfSource)
{
	for (int i = 0; i < sizeOfSource; i++)
	{
		destination[i] = source[i];
	}
	destination[sizeOfSource] = '\0';
	return;
}
MonsterCard::MonsterCard()
{
	name[0] = '\0';
	attackPoints = 0;
	defencePoints = 0;
}
MonsterCard::MonsterCard(const char name[25], const int& attackPoints, const int& defencepoints)
{
	setName(name);
	setAttackPoints(attackPoints);
	setDefencePoints(defencepoints);
}
MonsterCard::MonsterCard(const MonsterCard& source)
{
	setName(source.name);
	setAttackPoints(source.attackPoints);
	setDefencePoints(source.defencePoints);
}
void MonsterCard::setName(const char inputName[25])
{
	int inputNameSize = sizeOfStr(inputName);
	if (inputNameSize == 0)
	{
		name[0] = '\0';
		return;
	}
	else if (inputNameSize <1|| inputNameSize >= 25)
	{
		cout << "Too big input name. Name of monster card must be within [1,24] range !" << endl;
		return;
	}
	myStrCopy(name, inputName, inputNameSize);
	return;
}
char* MonsterCard::getName()const
{
	//we doing as that because our name is static located char pointer but the functions requires 
	//to return a char* so we alocated dynamic copy of name and return it
	int sizeOfname = 0;
	for (int i = 0; name[i]!='\0'; i++)
	{
		++sizeOfname;

	}
	char* nameDynamic = new char[sizeOfname + 1];
	for (int i = 0; i < sizeOfname; i++)
	{
		nameDynamic[i] = name[i];
	}
	nameDynamic[sizeOfname] = '\0';
	return nameDynamic;
}
void MonsterCard::setAttackPoints(const int inputAttackPoints)
{
	if (inputAttackPoints < 0)
	{
		return;
	}
	this->attackPoints = inputAttackPoints;
	return;
}
int MonsterCard::getAttackPoints()const
{
	return attackPoints;
}
void MonsterCard::setDefencePoints(const int defencePoints)
{
	if (defencePoints < 0)
	{
		return;
	}
	this->defencePoints = defencePoints;
}
int MonsterCard::getDefencePoints()const
{
	return defencePoints;
}