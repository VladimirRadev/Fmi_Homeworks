/**
* Solution to homework assignment 1
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021
*
* @author Vladimir Radev
* @idnumber 62530
* @task 2
* @compiler VC
*/


#ifndef MonsterCard1
#define MonsterCard1  1
#include <cstring>
class MonsterCard
{
private:
	char name[25];
	int attackPoints;
	int defencePoints;
	int sizeOfStr(const char* str);
	void myStrCopy(char* destination, const char* source, const int sizeOfSource);
public:
	MonsterCard();
	MonsterCard(const char name[25], const int& attackPoints, const int& defencepoints);
	MonsterCard(const MonsterCard& copy);
	void setName(const char[25]);
	char* getName()const;
	void setAttackPoints(const int inputAttackPoints);
	int getAttackPoints()const;
	void setDefencePoints(const int inputDefencePoints);
	int getDefencePoints()const;

	

};

#endif // !MonsterCard

