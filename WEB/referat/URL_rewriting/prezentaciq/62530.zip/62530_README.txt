Съдържание на архива:
   1) 62530.pptx
   2) 62530_invite.jpg
   3) 62530_demo1.mp4
   4) 62530_README.txt

Владимир Радев СИ 3 курс фн.62530 
email: vladimiradev@gmail.com