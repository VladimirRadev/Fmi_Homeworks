ф.н.: 62132
Таня Христова
tanche98@gmail.com

Съдържание на архива:
62132.pdf - слайдове на презентацията
62132_invite.png - покана

Демото е твърде голямо по размер, за да се качи в мудъл. Линк към него:

https://drive.google.com/file/d/1PMDRG2MO10pcSepiAIjKi6N_DGf3PK0C/view?usp=sharing

